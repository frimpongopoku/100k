@extends('navs.app')
@section('custom-title')

@endsection 

@section('custom-style')

@endsection
@section('content')

@endsection 


@section('custom-js')

@endsection