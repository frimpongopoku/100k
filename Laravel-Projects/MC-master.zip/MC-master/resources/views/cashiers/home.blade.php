@extends('navs.app')
@section('custom-title')
  Accounting
@endsection 
@section('custom-style')
@endsection
@section('content')
  <div class=" phone-m-zero phone-p-zero col-md-10 col-lg-10 col-sm-10 col-xs-12 offset-md-1" style="padding:30px;"> 
    <div class=" phone-m-zero">
      <div id="react-acc-div"> 
      </div>
    </div>
  </div>
@endsection 
@section('custom-js')
@endsection