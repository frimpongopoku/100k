

<div style='padding:30px'>
  <h4>Here is a comparison of items counted by the kitchen stuff <br> and the staff at the centers. </h4>
  <h5>The items were shipped form Kitchen A, and counted at center B</h5>
  <div>
    <div style='margin:15px;font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style='color:darkgreen'>45</span></p>
    </div>
    <hr style='width:20%; display:inline-block'/>
    <div style='font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style=''>23</span></p>
    </div>
  </div>
  
  <div>
    <div style='margin:15px;font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style='color:darkgreen'>45</span></p>
    </div>
    <hr style='width:20%; display:inline-block'/>
    <div style='font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style=''>23</span></p>
    </div>
  </div>
  
  <div>
    <div style='margin:15px;font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style='color:darkgreen'>45</span></p>
    </div>
    <hr style='width:20%; display:inline-block'/>
    <div style='font-weight:700;color:darkgreen;border-radius:7px;padding:5px 15px;border:solid 2px #ccc; display:inline-block'>
      <p>Cake <span style=''>23</span></p>
    </div>
  </div>
  
  
  <br>
  <hr>
  <br>
  <a href="/get/some" style="text-decoration: none; color:black;border:solid 2px black; padding:15px; margin:10px;border-radius:5px;">Confirm</a>
</div>