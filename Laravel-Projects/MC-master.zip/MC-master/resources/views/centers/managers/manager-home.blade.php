@extends('navs.app')
@section('custom-title')
  Manager
@endsection 

@section('custom-style')
@endsection
@section('content')
  <div class="phone-m-zero phone-p-zero col-md-10 col-lg-10 col-sm-10 col-xs-12 offset-md-1" style="padding:30px;"> 
    <div id="react-manager-div"> 
    </div>
  </div>
    
@endsection 

@section('custom-js')
@endsection