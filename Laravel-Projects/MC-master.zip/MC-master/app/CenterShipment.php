<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CenterShipment extends Model
{
    protected $guarded = [];
}
