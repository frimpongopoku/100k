<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompleteShipment extends Model
{
    protected $guarded = [];
}
