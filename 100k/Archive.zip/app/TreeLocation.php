<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TreeLocation extends Model
{
    //
}
