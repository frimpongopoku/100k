<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTree extends Model
{
    //
}
