<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>100kChallenge</title>

    <!-- Scripts -->
   
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script type="module" src="<?php echo e(asset('js/extra/Scanner.js')); ?>" defer></script>
    <script type="module" src="<?php echo e(asset('js/extra/100k.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/extra/anime.js')); ?>" defer></script>

    <!-- Fonts -->

    <link rel='icon' href="<?php echo e(asset('default-imgs/100k-footer.png')); ?>"/>
    
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Google+Sans:200,300,400,500,700,800,900" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/extra.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app" class="phone-body-fix">
        <nav class="navbar navbar-expand-md navbar-light bg-white  stick-to-top z-depth-1 nav-border " style="height:70px;">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('default-imgs/100k-ico.png')); ?>" style="width:190px" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav ml-auto phone-nav-tweak">
                      <li class="nav-item">
                        <a class="nav-link" href="/">HOME</a>
                     </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#about-anchor">ABOUT US</a>
                     </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#sponsor-anchor">SPONSORS</a>
                     </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#scanner">PLANT WITH US</a>
                     </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#map-anchor">MY TREES</a>
                     </li>

                     <?php if(Auth::user()): ?>
                        <li class="nav-item dropdown">
                          <a style="text-transform:uppercase" id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                              <b><?php echo e(Auth::user()->name); ?></b> <span class="caret"></span>
                          </a>

                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                                  <?php echo e(__('Logout')); ?>

                              </a>

                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                  <?php echo csrf_field(); ?>
                              </form>
                          </div>
                      </li>
                     <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    
                </div>
            </div>
        </nav>

        
            <?php echo $__env->yieldContent('content'); ?>
      
    </div>

    <?php echo $__env->yieldContent('custom-js'); ?>
  <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_API_KEY')); ?>&callback=initMap"
    async defer></script>

    
</body>
</html>
<?php /**PATH /Users/frimpongopokuagyemang/Documents/laravel/100k/100k/resources/views/layouts/welcome-nav.blade.php ENDPATH**/ ?>