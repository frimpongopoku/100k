
  // 100k's  Firebase configuration
  export const  firebaseConfig = {
    apiKey: "AIzaSyDqOwnZwkoRJ0WSXGpYdfO0y5lhlqBaFNE",
    authDomain: "klegacy.firebaseapp.com",
    databaseURL: "https://klegacy.firebaseio.com",
    projectId: "klegacy",
    storageBucket: "klegacy.appspot.com",
    messagingSenderId: "290415953022",
    appId: "1:290415953022:web:b65c19860a60f430df442f"
  };
  

